class LSConfigParseException(Exception):
    """ """


class LabelStudioXMLSyntaxErrorSentryIgnored(Exception):
    """ """


class LabelStudioValidationErrorSentryIgnored(Exception):
    """ """
